package com.gqt;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import org.hibernate.*;
import org.hibernate.cfg.Configuration;

public class DeleteRecord extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int sid = Integer.parseInt(request.getParameter("sid"));

		// Hibernate session setup
		SessionFactory sf = new Configuration().configure().buildSessionFactory();
		Session session = sf.openSession();
		session.beginTransaction();

		Student s = session.get(Student.class, sid);
		if (s != null) {
			session.delete(s);
			session.getTransaction().commit();
		}

		session.close();
		response.sendRedirect("DisplayRecord");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
        
    }
}
